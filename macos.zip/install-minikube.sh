#!/usr/bin/env sh

brew install minikube
