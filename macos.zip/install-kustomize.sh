#!/usr/bin/env sh

brew install kustomize
