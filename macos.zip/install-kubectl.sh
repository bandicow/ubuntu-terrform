#!/usr/bin/env sh

brew install kubectl
