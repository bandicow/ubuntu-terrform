#!/usr/bin/env sh

# Include docker-compose
brew install --cask docker
